线性代数 · Arietids Learn

覆盖范围：矩阵、行列式、向量空间、特征值、Jordan 标准形与二次型
在线目录：https://learn.arietids.net/courses/linear-algebra/

这是个人课程复习笔记。内容可能存在疏漏，请以课程正式要求为准。
Markdown 可用 Obsidian 或其他支持数学公式的阅读器打开。
HTML 演示可用浏览器直接打开。

来源标记随笔记保留。第三方引文、题目和课件内容的权利属于原作者。
本资料包不包含原教材、原课件或试卷。
